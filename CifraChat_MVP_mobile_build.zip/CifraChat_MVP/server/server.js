import { randomUUID } from 'node:crypto';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { createServer } from 'node:http';
import { WebSocketServer, WebSocket } from 'ws';

const port = Number(process.env.PORT || 8080);
const dataFile = resolve(process.env.DATA_FILE || './data/cifra-chat.json');
const maxPendingPerUser = 500;
const inviteToken = process.env.INVITE_TOKEN || '';
const server = createServer((req, res) => {
  if (req.url === '/health' || req.url === '/healthz') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ ok: true, service: 'CifraChat relay' }));
    return;
  }
  res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' });
  res.end('CifraChat relay is running. Connect using WebSocket.');
});
const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });

const online = new Map();
let publicKeys = {};
let pending = {};
let writeQueue = Promise.resolve();

function normalizeUser(user) {
  return String(user || '').trim().toLowerCase();
}

async function loadStore() {
  try {
    const saved = JSON.parse(await readFile(dataFile, 'utf8'));
    publicKeys = saved.publicKeys && typeof saved.publicKeys === 'object' ? saved.publicKeys : {};
    pending = saved.pending && typeof saved.pending === 'object' ? saved.pending : {};
  } catch (error) {
    if (error.code !== 'ENOENT') {
      console.error(`No se pudo leer ${dataFile}; se inicia una cola vacía:`, error.message);
    }
  }
}

function persistStore() {
  const snapshot = JSON.stringify({ publicKeys, pending });
  writeQueue = writeQueue.then(async () => {
    await mkdir(dirname(dataFile), { recursive: true });
    const temporary = `${dataFile}.tmp`;
    await writeFile(temporary, snapshot, { encoding: 'utf8', mode: 0o600 });
    await rename(temporary, dataFile);
  });
  return writeQueue;
}

function safeSend(ws, payload) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload));
    return true;
  }
  return false;
}

function queueFor(user, payload) {
  const list = pending[user] || [];
  list.push(payload);
  if (list.length > maxPendingPerUser) list.splice(0, list.length - maxPendingPerUser);
  pending[user] = list;
  return persistStore();
}

function deliverPending(user, ws) {
  for (const payload of pending[user] || []) safeSend(ws, payload);
}

function removePending(user, messageId) {
  const list = pending[user] || [];
  const remaining = list.filter((item) => item.messageId !== messageId);
  if (remaining.length === list.length) return Promise.resolve(false);
  if (remaining.length) pending[user] = remaining;
  else delete pending[user];
  return persistStore().then(() => true);
}

server.on('upgrade', (req, socket, head) => {
  const requestUrl = new URL(req.url || '/', 'http://localhost');
  const pathname = requestUrl.pathname;
  if (pathname !== '/' && pathname !== '/0/' && pathname !== '/ws') {
    socket.write('HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }
  if (inviteToken && requestUrl.searchParams.get('invite') !== inviteToken) {
    socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
});

function broadcastUsers() {
  const users = Object.keys(publicKeys).map((user) => ({
    user,
    online: online.has(user),
  }));
  for (const ws of online.values()) safeSend(ws, { type: 'users', users });
}

wss.on('connection', (ws) => {
  let registeredUser = null;

  ws.on('message', async (buffer) => {
    try {
      const data = JSON.parse(buffer.toString('utf8'));

      if (data.type === 'register') {
        const displayUser = String(data.user || '').trim();
        const user = normalizeUser(displayUser);
        const publicKey = String(data.publicKey || '').trim();
        if (displayUser.length < 3 || displayUser.length > 40 || !publicKey) {
          safeSend(ws, { type: 'error', message: 'Registro inválido' });
          return;
        }

        const previous = online.get(user);
        if (previous && previous !== ws) previous.close(4001, 'Nueva conexión');
        registeredUser = user;
        online.set(user, ws);
        publicKeys[user] = publicKey;
        await persistStore();
        safeSend(ws, { type: 'registered', user: displayUser });
        deliverPending(user, ws);
        broadcastUsers();
        return;
      }

      if (data.type === 'getKey') {
        if (!registeredUser) {
          safeSend(ws, { type: 'error', message: 'Regístrate antes de buscar usuarios' });
          return;
        }
        const user = normalizeUser(data.user);
        safeSend(ws, {
          type: 'key',
          user: String(data.user || '').trim(),
          publicKey: publicKeys[user] || null,
          requestId: data.requestId || null,
        });
        return;
      }

      if (data.type === 'listUsers') {
        if (!registeredUser) {
          safeSend(ws, { type: 'error', message: 'Regístrate antes de buscar usuarios' });
          return;
        }
        broadcastUsers();
        return;
      }

      if (data.type === 'sync') {
        if (!registeredUser) {
          safeSend(ws, { type: 'error', message: 'Regístrate antes de sincronizar' });
          return;
        }
        deliverPending(registeredUser, ws);
        return;
      }

      if (data.type === 'send') {
        const from = normalizeUser(data.from);
        const to = normalizeUser(data.to);
        if (!registeredUser || from !== registeredUser || !to || to === from || !data.box) {
          safeSend(ws, { type: 'error', message: 'Mensaje inválido' });
          return;
        }

        const payload = {
          type: 'message',
          messageId: randomUUID(),
          from: String(data.from).trim(),
          box: data.box,
          receivedAt: Date.now(),
        };
        await queueFor(to, payload);
        const recipient = online.get(to);
        const delivered = recipient ? safeSend(recipient, payload) : false;
        safeSend(ws, { type: 'delivery', to: String(data.to).trim(), ok: delivered });
        return;
      }

      if (data.type === 'ack') {
        if (!registeredUser || typeof data.messageId !== 'string') return;
        const removed = await removePending(registeredUser, data.messageId);
        if (removed) safeSend(ws, { type: 'acknowledged', messageId: data.messageId });
        return;
      }

      safeSend(ws, { type: 'error', message: 'Tipo de mensaje desconocido' });
    } catch (error) {
      console.error('Error procesando mensaje WebSocket:', error.message);
      safeSend(ws, { type: 'error', message: 'No se pudo procesar el mensaje' });
    }
  });

  ws.on('close', () => {
    if (registeredUser && online.get(registeredUser) === ws) {
      online.delete(registeredUser);
      broadcastUsers();
    }
  });
});

await loadStore();
server.listen(port, '0.0.0.0', () => {
  console.log(`CifraChat relay escuchando en el puerto ${port}`);
  console.log(`Cola persistente: ${dataFile}`);
  console.log('El servidor transporta cajas cifradas y no posee las claves privadas.');
});
