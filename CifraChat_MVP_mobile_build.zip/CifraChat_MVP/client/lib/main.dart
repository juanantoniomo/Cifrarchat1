import 'dart:async';

import 'package:cryptography/cryptography.dart';
import 'package:cryptography_flutter/cryptography_flutter.dart';
import 'package:flutter/material.dart';

import 'chat_socket.dart';
import 'e2ee_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterCryptography.enable();
  runApp(const CifraChatApp());
}

class CifraChatApp extends StatelessWidget {
  const CifraChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'CifraChat',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _user = TextEditingController();
  final _server = TextEditingController(text: 'ws://10.0.2.2:8080');
  bool _busy = false;
  String? _error;

  Future<void> _enter() async {
    final username = _user.text.trim();
    final server = _server.text.trim();
    if (username.length < 3 || server.isEmpty) {
      setState(() => _error = 'Pon un usuario de al menos 3 caracteres y la dirección del servidor.');
      return;
    }

    setState(() {
      _busy = true;
      _error = null;
    });

    try {
      final crypto = E2eeService();
      await crypto.initialize();
      final socket = ChatSocket();
      await socket.connect(
        serverUrl: server,
        username: username,
        publicKey: crypto.publicKeyBase64,
      );

      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => ChatPage(
            username: username,
            crypto: crypto,
            socket: socket,
          ),
        ),
      );
    } catch (e) {
      setState(() => _error = 'No se pudo conectar: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.lock_outline, size: 72),
                  const SizedBox(height: 16),
                  Text('CifraChat', style: Theme.of(context).textTheme.headlineLarge, textAlign: TextAlign.center),
                  const SizedBox(height: 8),
                  const Text('Mensajes cifrados de extremo a extremo', textAlign: TextAlign.center),
                  const SizedBox(height: 32),
                  TextField(
                    controller: _user,
                    decoration: const InputDecoration(
                      labelText: 'Tu usuario',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.person_outline),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _server,
                    keyboardType: TextInputType.url,
                    decoration: const InputDecoration(
                      labelText: 'Servidor WebSocket',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.dns_outlined),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                  ],
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    onPressed: _busy ? null : _enter,
                    icon: _busy
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.login),
                    label: const Text('Entrar'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ChatMessage {
  const ChatMessage({required this.text, required this.mine, required this.time});
  final String text;
  final bool mine;
  final DateTime time;
}

class ChatPage extends StatefulWidget {
  const ChatPage({
    super.key,
    required this.username,
    required this.crypto,
    required this.socket,
  });

  final String username;
  final E2eeService crypto;
  final ChatSocket socket;

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _contact = TextEditingController();
  final _message = TextEditingController();
  final List<ChatMessage> _messages = [];
  final Map<String, SimplePublicKey> _publicKeys = {};
  StreamSubscription<Map<String, dynamic>>? _subscription;
  String? _activeContact;
  String? _status;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _subscription = widget.socket.events.listen(_onEvent);
  }

  Future<SimplePublicKey> _keyFor(String user) async {
    final cached = _publicKeys[user];
    if (cached != null) return cached;
    final encoded = await widget.socket.getPublicKey(user);
    final key = widget.crypto.publicKeyFromBase64(encoded);
    _publicKeys[user] = key;
    return key;
  }

  Future<void> _selectContact() async {
    final user = _contact.text.trim();
    if (user.isEmpty || user == widget.username) return;
    setState(() => _status = 'Comprobando $user…');
    try {
      await _keyFor(user);
      setState(() {
        _activeContact = user;
        _messages.clear();
        _status = 'Chat cifrado con $user';
      });
    } catch (e) {
      setState(() => _status = 'No se encontró ese usuario: $e');
    }
  }

  Future<void> _send() async {
    final contact = _activeContact;
    final text = _message.text.trim();
    if (contact == null || text.isEmpty || _sending) return;

    setState(() => _sending = true);
    try {
      final remoteKey = await _keyFor(contact);
      final encrypted = await widget.crypto.encrypt(
        plaintext: text,
        from: widget.username,
        to: contact,
        remotePublicKey: remoteKey,
      );

      widget.socket.sendJson({
        'type': 'send',
        'to': contact,
        'from': widget.username,
        'box': encrypted.toJson(),
      });

      setState(() {
        _messages.add(ChatMessage(text: text, mine: true, time: DateTime.now()));
        _message.clear();
      });
    } catch (e) {
      setState(() => _status = 'Error enviando: $e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _onEvent(Map<String, dynamic> event) async {
    if (event['type'] == 'message') {
      final from = event['from'] as String?;
      final boxRaw = event['box'];
      if (from == null || boxRaw is! Map) return;
      try {
        final remoteKey = await _keyFor(from);
        final encrypted = EncryptedBox.fromJson(Map<String, dynamic>.from(boxRaw));
        final text = await widget.crypto.decrypt(
          encrypted: encrypted,
          from: from,
          to: widget.username,
          remotePublicKey: remoteKey,
        );
        if (!mounted) return;
        setState(() {
          _activeContact ??= from;
          _contact.text = _activeContact!;
          if (_activeContact == from) {
            _messages.add(ChatMessage(text: text, mine: false, time: DateTime.now()));
          }
          _status = 'Mensaje recibido de $from';
        });
      } catch (e) {
        if (mounted) setState(() => _status = 'Mensaje recibido, pero no se pudo descifrar: $e');
      }
    } else if (event['type'] == 'registered') {
      if (mounted) setState(() => _status = 'Conectado como ${widget.username}');
    } else if (event['type'] == 'delivery') {
      final ok = event['ok'] == true;
      if (mounted) setState(() => _status = ok ? 'Entregado al servidor' : 'Destinatario sin conexión; queda en cola');
    } else if (event['type'] == 'error') {
      if (mounted) setState(() => _status = event['message']?.toString());
    } else if (event['type'] == 'socketClosed') {
      if (mounted) setState(() => _status = 'Conexión cerrada');
    }
  }

  @override
  void dispose() {
    _subscription?.cancel();
    widget.socket.close();
    _contact.dispose();
    _message.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CifraChat'),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.lock, size: 20),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _contact,
                    textInputAction: TextInputAction.done,
                    onSubmitted: (_) => _selectContact(),
                    decoration: const InputDecoration(
                      labelText: 'Usuario del contacto',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.person_search_outlined),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(onPressed: _selectContact, child: const Text('Abrir')),
              ],
            ),
          ),
          if (_status != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              child: Text(_status!, style: Theme.of(context).textTheme.bodySmall),
            ),
          const Divider(height: 1),
          Expanded(
            child: _activeContact == null
                ? const Center(child: Text('Escribe el usuario de un contacto para empezar.'))
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _messages.length,
                    itemBuilder: (context, index) {
                      final item = _messages[index];
                      return Align(
                        alignment: item.mine ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          constraints: const BoxConstraints(maxWidth: 330),
                          decoration: BoxDecoration(
                            color: item.mine
                                ? Theme.of(context).colorScheme.primaryContainer
                                : Theme.of(context).colorScheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text(item.text),
                        ),
                      );
                    },
                  ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _message,
                      enabled: _activeContact != null,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      decoration: const InputDecoration(
                        hintText: 'Mensaje cifrado…',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _activeContact == null || _sending ? null : _send,
                    icon: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
