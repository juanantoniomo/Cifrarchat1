import 'dart:async';

import 'package:cryptography/cryptography.dart';
import 'package:cryptography_flutter/cryptography_flutter.dart';
import 'package:flutter/material.dart';

import 'chat_socket.dart';
import 'e2ee_service.dart';

const _defaultServerUrl =
    'wss://cifrarchat.bonto.run/?invite=31aaef21c018d35278fadb8687b049eaafc604542992fef5098487ee3341e40b';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterCryptography.enable();
  runApp(const CifraChatApp());
}

class CifraChatApp extends StatelessWidget {
  const CifraChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'CifraChat',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _user = TextEditingController();
  bool _busy = false;
  String? _error;

  Future<void> _enter() async {
    final username = _user.text.trim();
    if (username.length < 3) {
      setState(() => _error = 'Pon un usuario de al menos 3 caracteres.');
      return;
    }

    setState(() {
      _busy = true;
      _error = null;
    });

    try {
      final crypto = E2eeService();
      await crypto.initialize();
      final socket = ChatSocket();
      await socket.connect(
        serverUrl: _defaultServerUrl,
        username: username,
        publicKey: crypto.publicKeyBase64,
      );

      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => ChatPage(
            username: username,
            crypto: crypto,
            socket: socket,
          ),
        ),
      );
    } catch (e) {
      setState(() => _error = 'No se pudo conectar: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.lock_outline, size: 72),
                  const SizedBox(height: 16),
                  Text('CifraChat', style: Theme.of(context).textTheme.headlineLarge, textAlign: TextAlign.center),
                  const SizedBox(height: 8),
                  const Text('Mensajes cifrados de extremo a extremo', textAlign: TextAlign.center),
                  const SizedBox(height: 32),
                  TextField(
                    controller: _user,
                    decoration: const InputDecoration(
                      labelText: 'Tu usuario',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.person_outline),
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Servidor configurado automáticamente',
                    textAlign: TextAlign.center,
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                  ],
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    onPressed: _busy ? null : _enter,
                    icon: _busy
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.login),
                    label: const Text('Entrar'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ChatMessage {
  const ChatMessage({required this.text, required this.mine, required this.time});
  final String text;
  final bool mine;
  final DateTime time;
}

class ChatPage extends StatefulWidget {
  const ChatPage({
    super.key,
    required this.username,
    required this.crypto,
    required this.socket,
  });

  final String username;
  final E2eeService crypto;
  final ChatSocket socket;

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _contact = TextEditingController();
  final _message = TextEditingController();
  final List<ChatMessage> _messages = [];
  final Map<String, SimplePublicKey> _publicKeys = {};
  StreamSubscription<Map<String, dynamic>>? _subscription;
  String? _activeContact;
  String? _status;
  bool _sending = false;
  List<Map<String, dynamic>> _users = [];

  @override
  void initState() {
    super.initState();
    _subscription = widget.socket.events.listen(_onEvent);
  }

  Future<SimplePublicKey> _keyFor(String user) async {
    final cached = _publicKeys[user];
    if (cached != null) return cached;
    final encoded = await widget.socket.getPublicKey(user);
    final key = widget.crypto.publicKeyFromBase64(encoded);
    _publicKeys[user] = key;
    return key;
  }

  Future<void> _selectContact() async {
    final user = _contact.text.trim();
    if (user.isEmpty || user == widget.username) return;
    setState(() => _status = 'Comprobando $user…');
    try {
      await _keyFor(user);
      if (!mounted) return;
      setState(() {
        _activeContact = user;
        _messages.clear();
        _status = 'Chat cifrado con $user';
      });
      widget.socket.sendJson({'type': 'sync'});
    } catch (e) {
      if (mounted) setState(() => _status = 'No se encontró ese usuario: $e');
    }
  }

  Future<void> _send() async {
    final contact = _activeContact;
    final text = _message.text.trim();
    if (contact == null || text.isEmpty || _sending) return;

    setState(() => _sending = true);
    try {
      final remoteKey = await _keyFor(contact);
      final encrypted = await widget.crypto.encrypt(
        plaintext: text,
        from: widget.username,
        to: contact,
        remotePublicKey: remoteKey,
      );

      widget.socket.sendJson({
        'type': 'send',
        'to': contact,
        'from': widget.username,
        'box': encrypted.toJson(),
      });

      setState(() {
        _messages.add(ChatMessage(text: text, mine: true, time: DateTime.now()));
        _message.clear();
      });
    } catch (e) {
      setState(() => _status = 'Error enviando: $e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _onEvent(Map<String, dynamic> event) async {
    if (event['type'] == 'message') {
      final from = event['from'] as String?;
      final boxRaw = event['box'];
      if (from == null || boxRaw is! Map) return;
      try {
        final remoteKey = await _keyFor(from);
        final encrypted = EncryptedBox.fromJson(Map<String, dynamic>.from(boxRaw));
        final text = await widget.crypto.decrypt(
          encrypted: encrypted,
          from: from,
          to: widget.username,
          remotePublicKey: remoteKey,
        );
        if (!mounted) return;
        final active = _activeContact;
        final showInCurrentChat = active == null || active == from;
        setState(() {
          if (active == null) {
            _activeContact = from;
            _contact.text = from;
          }
          if (showInCurrentChat) {
            _messages.add(ChatMessage(text: text, mine: false, time: DateTime.now()));
            _status = 'Mensaje recibido de $from';
          } else {
            _status = 'Tienes un mensaje pendiente de $from. Abre ese chat para verlo.';
          }
        });
        // Keep messages for another conversation on the relay until that chat is opened.
        // Selecting the conversation sends `sync`, then its messages are acknowledged.
        if (showInCurrentChat && event['messageId'] is String) {
          widget.socket.sendJson({'type': 'ack', 'messageId': event['messageId']});
        }
      } catch (e) {
        if (mounted) setState(() => _status = 'Mensaje recibido, pero no se pudo descifrar: $e');
      }
    } else if (event['type'] == 'registered') {
      if (mounted) setState(() => _status = 'Conectado como ${widget.username}');
    } else if (event['type'] == 'users') {
      final rawUsers = event['users'];
      if (rawUsers is List && mounted) {
        setState(() => _users = rawUsers
            .whereType<Map>()
            .map((item) => Map<String, dynamic>.from(item))
            .where((item) => item['user'] is String && item['user'] != widget.username.toLowerCase())
            .toList()
          ..sort((a, b) {
            final onlineOrder = (b['online'] == true ? 1 : 0).compareTo(a['online'] == true ? 1 : 0);
            return onlineOrder != 0 ? onlineOrder : (a['user'] as String).compareTo(b['user'] as String);
          }));
      }
    } else if (event['type'] == 'delivery') {
      final ok = event['ok'] == true;
      if (mounted) setState(() => _status = ok ? 'Enviado; esperando confirmación del contacto' : 'Guardado; llegará cuando el contacto se conecte');
    } else if (event['type'] == 'acknowledged') {
      if (mounted) setState(() => _status = 'El contacto recibió el mensaje');
    } else if (event['type'] == 'error') {
      if (mounted) setState(() => _status = event['message']?.toString());
    } else if (event['type'] == 'socketClosed') {
      if (mounted) setState(() => _status = 'Conexión cerrada');
    }
  }

  @override
  void dispose() {
    _subscription?.cancel();
    widget.socket.close();
    _contact.dispose();
    _message.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CifraChat'),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.lock, size: 20),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _contact,
                    textInputAction: TextInputAction.done,
                    onSubmitted: (_) => _selectContact(),
                    decoration: const InputDecoration(
                      labelText: 'Usuario del contacto',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.person_search_outlined),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(onPressed: _selectContact, child: const Text('Abrir')),
              ],
            ),
          ),
          if (_users.isNotEmpty)
            SizedBox(
              height: 54,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                scrollDirection: Axis.horizontal,
                itemCount: _users.length,
                separatorBuilder: (_, __) => const SizedBox(width: 6),
                itemBuilder: (context, index) {
                  final item = _users[index];
                  final user = item['user'] as String;
                  final isOnline = item['online'] == true;
                  return ActionChip(
                    avatar: Icon(isOnline ? Icons.circle : Icons.circle_outlined, size: 12,
                        color: isOnline ? Colors.green : Colors.grey),
                    label: Text('$user · ${isOnline ? 'conectado' : 'desconectado'}'),
                    onPressed: () {
                      _contact.text = user;
                      _selectContact();
                    },
                  );
                },
              ),
            ),
          if (_status != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              child: Text(_status!, style: Theme.of(context).textTheme.bodySmall),
            ),
          const Divider(height: 1),
          Expanded(
            child: _activeContact == null
                ? const Center(child: Text('Escribe el usuario de un contacto para empezar.'))
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _messages.length,
                    itemBuilder: (context, index) {
                      final item = _messages[index];
                      return Align(
                        alignment: item.mine ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          constraints: const BoxConstraints(maxWidth: 330),
                          decoration: BoxDecoration(
                            color: item.mine
                                ? Theme.of(context).colorScheme.primaryContainer
                                : Theme.of(context).colorScheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text(item.text),
                        ),
                      );
                    },
                  ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _message,
                      enabled: _activeContact != null,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      decoration: const InputDecoration(
                        hintText: 'Mensaje cifrado…',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _activeContact == null || _sending ? null : _send,
                    icon: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
