import 'dart:convert';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

String _canonicalUser(String user) => user.trim().toLowerCase();

class EncryptedBox {
  const EncryptedBox({
    required this.nonce,
    required this.cipherText,
    required this.mac,
  });

  final String nonce;
  final String cipherText;
  final String mac;

  Map<String, dynamic> toJson() => {
        'nonce': nonce,
        'cipherText': cipherText,
        'mac': mac,
      };

  factory EncryptedBox.fromJson(Map<String, dynamic> json) => EncryptedBox(
        nonce: json['nonce'] as String,
        cipherText: json['cipherText'] as String,
        mac: json['mac'] as String,
      );
}

class E2eeService {
  static const _privateKeyName = 'x25519_private_key_v1';
  static const _publicKeyName = 'x25519_public_key_v1';
  static const _storage = FlutterSecureStorage();

  final X25519 _x25519 = X25519();
  final AesGcm _aes = AesGcm.with256bits();
  final Hkdf _hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);

  SimpleKeyPair? _keyPair;
  SimplePublicKey? _publicKey;

  Future<void> initialize() async {
    final privateB64 = await _storage.read(key: _privateKeyName);
    final publicB64 = await _storage.read(key: _publicKeyName);

    if (privateB64 != null && publicB64 != null) {
      final privateBytes = base64Decode(privateB64);
      final publicBytes = base64Decode(publicB64);
      final publicKey = SimplePublicKey(
        publicBytes,
        type: KeyPairType.x25519,
      );
      _keyPair = SimpleKeyPairData(
        privateBytes,
        publicKey: publicKey,
        type: KeyPairType.x25519,
      );
      _publicKey = publicKey;
      return;
    }

    final keyPair = await _x25519.newKeyPair();
    final privateBytes = await keyPair.extractPrivateKeyBytes();
    final publicKey = await keyPair.extractPublicKey();

    await _storage.write(
      key: _privateKeyName,
      value: base64Encode(privateBytes),
    );
    await _storage.write(
      key: _publicKeyName,
      value: base64Encode(publicKey.bytes),
    );

    _keyPair = keyPair;
    _publicKey = publicKey;
  }

  String get publicKeyBase64 {
    final key = _publicKey;
    if (key == null) {
      throw StateError('E2eeService no inicializado');
    }
    return base64Encode(key.bytes);
  }

  SimplePublicKey publicKeyFromBase64(String value) => SimplePublicKey(
        base64Decode(value),
        type: KeyPairType.x25519,
      );

  Future<SecretKey> _chatKey({
    required String myUser,
    required String otherUser,
    required SimplePublicKey remotePublicKey,
  }) async {
    final keyPair = _keyPair;
    if (keyPair == null) {
      throw StateError('E2eeService no inicializado');
    }

    final shared = await _x25519.sharedSecretKey(
      keyPair: keyPair,
      remotePublicKey: remotePublicKey,
    );

    // The relay treats usernames as case-insensitive. Use the same canonical
    // form for key derivation so `Mondi` and `mondi` produce the same chat key.
    final names = [_canonicalUser(myUser), _canonicalUser(otherUser)]..sort();
    final info = utf8.encode('cifra-chat-v1:${names[0]}:${names[1]}');
    return _hkdf.deriveKey(
      secretKey: shared,
      nonce: utf8.encode('cifra-chat-hkdf-salt-v1'),
      info: info,
    );
  }

  Future<EncryptedBox> encrypt({
    required String plaintext,
    required String from,
    required String to,
    required SimplePublicKey remotePublicKey,
  }) async {
    final key = await _chatKey(
      myUser: from,
      otherUser: to,
      remotePublicKey: remotePublicKey,
    );
    final aad = utf8.encode(
      'cifra-chat-msg-v1|${_canonicalUser(from)}|${_canonicalUser(to)}',
    );
    final box = await _aes.encrypt(
      utf8.encode(plaintext),
      secretKey: key,
      aad: aad,
    );

    return EncryptedBox(
      nonce: base64Encode(box.nonce),
      cipherText: base64Encode(box.cipherText),
      mac: base64Encode(box.mac.bytes),
    );
  }

  Future<String> decrypt({
    required EncryptedBox encrypted,
    required String from,
    required String to,
    required SimplePublicKey remotePublicKey,
  }) async {
    final key = await _chatKey(
      myUser: to,
      otherUser: from,
      remotePublicKey: remotePublicKey,
    );
    final aad = utf8.encode(
      'cifra-chat-msg-v1|${_canonicalUser(from)}|${_canonicalUser(to)}',
    );
    final box = SecretBox(
      base64Decode(encrypted.cipherText),
      nonce: base64Decode(encrypted.nonce),
      mac: Mac(base64Decode(encrypted.mac)),
    );
    final clear = await _aes.decrypt(
      box,
      secretKey: key,
      aad: aad,
    );
    return utf8.decode(clear);
  }
}
