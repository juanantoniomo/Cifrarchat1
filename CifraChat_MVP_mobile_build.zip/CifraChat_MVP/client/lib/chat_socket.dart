import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:web_socket_channel/web_socket_channel.dart';

class ChatSocket {
  WebSocketChannel? _channel;
  StreamSubscription<dynamic>? _subscription;
  Timer? _reconnectTimer;
  String? _serverUrl;
  String? _username;
  String? _publicKey;
  bool _closedByUser = false;
  Duration _retryDelay = const Duration(seconds: 1);

  // A single-subscription stream buffers the register-time delivery until ChatPage listens.
  final _events = StreamController<Map<String, dynamic>>();
  final Map<String, Completer<String>> _keyRequests = {};

  Stream<Map<String, dynamic>> get events => _events.stream;

  Future<void> connect({
    required String serverUrl,
    required String username,
    required String publicKey,
  }) async {
    _serverUrl = serverUrl;
    _username = username;
    _publicKey = publicKey;
    _closedByUser = false;
    await _open(retryIfFailed: false);
  }

  Future<void> _open({bool retryIfFailed = true}) async {
    final serverUrl = _serverUrl;
    final username = _username;
    final publicKey = _publicKey;
    if (_closedByUser || serverUrl == null || username == null || publicKey == null) return;

    final channel = WebSocketChannel.connect(Uri.parse(serverUrl));
    _channel = channel;
    try {
      await channel.ready;
    } catch (_) {
      if (_closedByUser) rethrow;
      _events.add({'type': 'socketError', 'message': 'No se pudo conectar; reintentando…'});
      if (retryIfFailed) {
        _scheduleReconnect(channel);
      } else {
        _channel = null;
      }
      rethrow;
    }
    if (_closedByUser || !identical(_channel, channel)) {
      await channel.sink.close();
      return;
    }
    _retryDelay = const Duration(seconds: 1);
    _subscription = channel.stream.listen(
      (raw) {
        final data = jsonDecode(raw as String) as Map<String, dynamic>;
        if (data['type'] == 'key' && data['requestId'] != null) {
          final id = data['requestId'] as String;
          final pending = _keyRequests.remove(id);
          final key = data['publicKey'];
          if (pending != null) {
            if (key is String && key.isNotEmpty) {
              pending.complete(key);
            } else {
              pending.completeError(StateError('Usuario no encontrado'));
            }
          }
        }
        _events.add(data);
      },
      onError: (Object error, StackTrace stack) {
        _events.add({'type': 'socketError', 'message': error.toString()});
        _scheduleReconnect(channel);
      },
      onDone: () {
        _events.add({'type': 'socketClosed'});
        _scheduleReconnect(channel);
      },
    );

    channel.sink.add(jsonEncode({
      'type': 'register',
      'user': username,
      'publicKey': publicKey,
    }));
  }

  void _scheduleReconnect(WebSocketChannel channel) {
    if (_closedByUser || !identical(_channel, channel) || _reconnectTimer != null) return;
    _channel = null;
    _reconnectTimer = Timer(_retryDelay, () {
      _reconnectTimer = null;
      _open().catchError((Object error) {
        _events.add({'type': 'socketError', 'message': error.toString()});
      });
    });
    final nextSeconds = (_retryDelay.inSeconds * 2).clamp(1, 30).toInt();
    _retryDelay = Duration(seconds: nextSeconds);
  }

  void sendJson(Map<String, dynamic> data) {
    final channel = _channel;
    if (channel == null) {
      throw StateError('Socket no conectado');
    }
    channel.sink.add(jsonEncode(data));
  }

  Future<String> getPublicKey(String username) {
    final requestId = '${DateTime.now().microsecondsSinceEpoch}-${Random.secure().nextInt(1 << 31)}';
    final completer = Completer<String>();
    _keyRequests[requestId] = completer;
    sendJson({
      'type': 'getKey',
      'user': username,
      'requestId': requestId,
    });
    return completer.future.timeout(
      const Duration(seconds: 8),
      onTimeout: () {
        _keyRequests.remove(requestId);
        throw TimeoutException('No se pudo obtener la clave pública');
      },
    );
  }

  Future<void> close() async {
    _closedByUser = true;
    _reconnectTimer?.cancel();
    _reconnectTimer = null;
    await _subscription?.cancel();
    await _channel?.sink.close();
    _channel = null;
    await _events.close();
  }
}
