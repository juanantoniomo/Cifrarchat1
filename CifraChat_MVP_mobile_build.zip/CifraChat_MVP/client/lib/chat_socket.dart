import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:web_socket_channel/web_socket_channel.dart';

class ChatSocket {
  WebSocketChannel? _channel;
  StreamSubscription<dynamic>? _subscription;

  final _events = StreamController<Map<String, dynamic>>.broadcast();
  final Map<String, Completer<String>> _keyRequests = {};

  Stream<Map<String, dynamic>> get events => _events.stream;

  Future<void> connect({
    required String serverUrl,
    required String username,
    required String publicKey,
  }) async {
    _channel = WebSocketChannel.connect(Uri.parse(serverUrl));
    await _channel!.ready;
    _subscription = _channel!.stream.listen(
      (raw) {
        final data = jsonDecode(raw as String) as Map<String, dynamic>;
        if (data['type'] == 'key' && data['requestId'] != null) {
          final id = data['requestId'] as String;
          final pending = _keyRequests.remove(id);
          final key = data['publicKey'];
          if (pending != null) {
            if (key is String && key.isNotEmpty) {
              pending.complete(key);
            } else {
              pending.completeError(StateError('Usuario no encontrado'));
            }
          }
        }
        _events.add(data);
      },
      onError: (Object error, StackTrace stack) {
        _events.add({'type': 'socketError', 'message': error.toString()});
      },
      onDone: () {
        _events.add({'type': 'socketClosed'});
      },
    );

    sendJson({
      'type': 'register',
      'user': username,
      'publicKey': publicKey,
    });
  }

  void sendJson(Map<String, dynamic> data) {
    final channel = _channel;
    if (channel == null) {
      throw StateError('Socket no conectado');
    }
    channel.sink.add(jsonEncode(data));
  }

  Future<String> getPublicKey(String username) {
    final requestId = '${DateTime.now().microsecondsSinceEpoch}-${Random.secure().nextInt(1 << 31)}';
    final completer = Completer<String>();
    _keyRequests[requestId] = completer;
    sendJson({
      'type': 'getKey',
      'user': username,
      'requestId': requestId,
    });
    return completer.future.timeout(
      const Duration(seconds: 8),
      onTimeout: () {
        _keyRequests.remove(requestId);
        throw TimeoutException('No se pudo obtener la clave pública');
      },
    );
  }

  Future<void> close() async {
    await _subscription?.cancel();
    await _channel?.sink.close();
    await _events.close();
  }
}
