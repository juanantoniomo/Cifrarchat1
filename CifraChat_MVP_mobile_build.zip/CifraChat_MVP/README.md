# CifraChat MVP

Prototipo de mensajería cifrada de extremo a extremo.

## Qué incluye

- Cliente Flutter para Android/iOS.
- Servidor relay WebSocket en Node.js.
- X25519 para acuerdo de secreto entre dos usuarios.
- HKDF-SHA256 para derivar una clave de chat de 256 bits.
- AES-256-GCM para cifrar y autenticar cada mensaje.
- Clave privada guardada con `flutter_secure_storage`.
- El servidor recibe `nonce + ciphertext + MAC`, nunca el texto original ni la clave privada.
- Cola temporal en memoria si el receptor está desconectado.

## IMPORTANTE: estado de seguridad

Este proyecto es un **MVP/prototipo**, no debe anunciarse todavía como equivalente a Signal o WhatsApp.

La versión actual usa una clave X25519 persistente por dispositivo y NO implementa Double Ratchet / Perfect Forward Secrecy. Tampoco implementa todavía verificación de huellas de seguridad, multi-dispositivo, rotación automática de claves, protección contra cambio malicioso de clave pública, autenticación de cuentas, TLS obligatorio ni persistencia segura del servidor.

Antes de publicar una app real se recomienda migrar la capa criptográfica de conversación a Signal Protocol (X3DH/PQXDH + Double Ratchet o la versión vigente), añadir verificación de identidad y someter la implementación a auditoría independiente.

## 1. Arrancar el servidor

Requisitos: Node.js 20+.

```bash
cd server
npm install
npm start
```

Quedará escuchando en:

```text
ws://0.0.0.0:8080
```

## 2. Preparar el cliente Flutter

Requisitos: Flutter reciente compatible con Dart 3.8+.

Como este ZIP contiene el código fuente esencial y no los directorios generados de Android/iOS, ejecuta una vez:

```bash
cd client
flutter create . --platforms=android,ios
flutter pub get
```

`flutter create .` conserva `lib/` y completa los proyectos nativos que Flutter necesita.

Después:

```bash
flutter run
```

## 3. Dirección del servidor

- Android Emulator: `ws://10.0.2.2:8080`
- iOS Simulator: normalmente `ws://127.0.0.1:8080`
- Teléfono físico: usa la IP LAN de tu ordenador, por ejemplo `ws://192.168.1.50:8080`.

El teléfono y el ordenador deben estar en la misma red para esta prueba local.

## 4. Probar dos usuarios

1. Arranca el servidor.
2. Abre la app en dos emuladores/teléfonos.
3. En uno entra como `juan`.
4. En el otro entra como `maria`.
5. En Juan abre el contacto `maria`.
6. En María abre el contacto `juan`.
7. Envía mensajes.

El servidor únicamente recibe estructuras del tipo:

```json
{
  "type": "message",
  "from": "juan",
  "box": {
    "nonce": "...",
    "cipherText": "...",
    "mac": "..."
  }
}
```

## Próximos pasos para versión real

1. Cuentas y autenticación segura.
2. HTTPS/WSS con certificado TLS.
3. Signal Protocol / Double Ratchet para forward secrecy.
4. Huellas/QR para verificar contactos.
5. Base de datos que almacene solo ciphertext.
6. Notificaciones push sin contenido del mensaje.
7. Fotos, notas de voz y archivos cifrados.
8. Grupos cifrados.
9. Bloqueo biométrico de la app.
10. Mensajes temporales.
11. Copias de seguridad cifradas opcionales.
12. Auditoría de seguridad antes de producción.
