# CifraChat MVP

Aplicación Flutter y relay WebSocket para probar mensajes cifrados entre usuarios.

## Funciones

- Lista de usuarios registrados y presencia conectado/desconectado.
- Búsqueda por nombre y chats con usuarios conectados o desconectados.
- Los nombres no distinguen mayúsculas también al derivar la clave del chat y verificar los mensajes.
- Cifrado X25519, HKDF-SHA256 y AES-256-GCM; la clave privada del dispositivo se guarda con `flutter_secure_storage`.
- Cola en el servidor de hasta 500 mensajes cifrados por usuario. Los mensajes de otro chat permanecen pendientes hasta que se abre esa conversación.
- Reconexión automática después de que se establezca la primera conexión.
- Endpoint de comprobación `/health`.

## Ejecutar el relay

Requiere Node.js 20 o posterior.

```bash
cd server
npm install
npm start
```

El servidor usa `PORT` y `DATA_FILE` si están definidos; de lo contrario escucha en el puerto 8080 y guarda los datos en `server/data/cifra-chat.json`. En el alojamiento, `DATA_FILE` debe apuntar a almacenamiento persistente para conservar la cola al reiniciar.

`INVITE_TOKEN` es opcional. Si se configura en el alojamiento, las conexiones WebSocket deben incluir el mismo valor como parámetro `?invite=`. El valor incluido en una APK es recuperable: sirve para limitar conexiones casuales, no identifica de forma segura a cada persona.

## Compilar el cliente

Requiere Flutter estable compatible con Dart 3.8+.

```bash
cd client
flutter create . --platforms=android --project-name cifra_chat --org com.cifrachat
flutter pub get
flutter analyze
flutter build apk --release
```

El workflow `.github/workflows/build-apk.yml` ejecuta esos pasos y publica el artefacto `CifraChat-APK`.

## Limitaciones importantes

Esto sigue siendo un prototipo. Los nombres de usuario no son cuentas autenticadas: otra persona podría registrar el mismo nombre. El relay no verifica la identidad de las claves públicas, y el protocolo no implementa Double Ratchet ni Perfect Forward Secrecy. No lo uses para conversaciones sensibles ni lo presentes como equivalente a Signal o WhatsApp.

Los mensajes para usuarios desconectados se guardan cifrados y se entregan cuando abren la app y conectan. **No hay notificación push si la app está cerrada.** Para eso hay que crear/configurar un proyecto Firebase, añadir su configuración Android a `client/android` y credenciales de servicio al servidor. Esos datos no estaban disponibles en este proyecto, así que la APK actual no puede enviar push.
