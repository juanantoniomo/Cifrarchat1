package com.cifrarchat1.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText passwordInput;
    private EditText messageInput;
    private TextView resultView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Cifrarchat1");

        int pad = dp(16);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Cifrarchat1");
        title.setTextSize(28f);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("MVP local: cifra y descifra mensajes en este teléfono. Todavía no envía mensajes por Internet.");
        subtitle.setPadding(0, dp(8), 0, dp(16));
        root.addView(subtitle);

        passwordInput = new EditText(this);
        passwordInput.setHint("Contraseña compartida (mínimo 8 caracteres)");
        passwordInput.setSingleLine(true);
        passwordInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(passwordInput, matchWrap());

        messageInput = new EditText(this);
        messageInput.setHint("Escribe texto para cifrar o pega aquí un mensaje CC1...");
        messageInput.setMinLines(5);
        messageInput.setGravity(android.view.Gravity.TOP);
        root.addView(messageInput, matchWrap());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);

        Button encryptButton = new Button(this);
        encryptButton.setText("Cifrar");
        encryptButton.setOnClickListener(v -> encrypt());
        actions.addView(encryptButton, weighted());

        Button decryptButton = new Button(this);
        decryptButton.setText("Descifrar");
        decryptButton.setOnClickListener(v -> decrypt());
        actions.addView(decryptButton, weighted());

        root.addView(actions, matchWrap());

        TextView resultLabel = new TextView(this);
        resultLabel.setText("Resultado");
        resultLabel.setTextSize(18f);
        resultLabel.setPadding(0, dp(16), 0, dp(6));
        root.addView(resultLabel);

        resultView = new TextView(this);
        resultView.setTextIsSelectable(true);
        resultView.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(resultView, matchWrap());

        LinearLayout utility = new LinearLayout(this);
        utility.setOrientation(LinearLayout.HORIZONTAL);

        Button copyButton = new Button(this);
        copyButton.setText("Copiar resultado");
        copyButton.setOnClickListener(v -> copyResult());
        utility.addView(copyButton, weighted());

        Button clearButton = new Button(this);
        clearButton.setText("Limpiar");
        clearButton.setOnClickListener(v -> clearAll());
        utility.addView(clearButton, weighted());

        root.addView(utility, matchWrap());

        TextView warning = new TextView(this);
        warning.setText("Importante: para hablar con otra persona ambos deben conocer la misma contraseña por un canal seguro. Esta versión no sustituye todavía a un sistema completo de cifrado extremo a extremo con gestión automática de claves.");
        warning.setPadding(0, dp(16), 0, dp(8));
        root.addView(warning);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private void encrypt() {
        try {
            resultView.setText(CryptoManager.encrypt(
                    messageInput.getText().toString(),
                    passwordInput.getText().toString()));
        } catch (Exception e) {
            showError(e);
        }
    }

    private void decrypt() {
        try {
            resultView.setText(CryptoManager.decrypt(
                    messageInput.getText().toString(),
                    passwordInput.getText().toString()));
        } catch (Exception e) {
            resultView.setText("");
            Toast.makeText(this, "No se pudo descifrar: revisa la contraseña y el mensaje.", Toast.LENGTH_LONG).show();
        }
    }

    private void copyResult() {
        String text = resultView.getText().toString();
        if (text.isEmpty()) {
            Toast.makeText(this, "No hay resultado para copiar.", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Cifrarchat1", text));
        Toast.makeText(this, "Resultado copiado.", Toast.LENGTH_SHORT).show();
    }

    private void clearAll() {
        messageInput.setText("");
        resultView.setText("");
        passwordInput.setText("");
    }

    private void showError(Exception e) {
        String message = e.getMessage();
        if (message == null || message.isEmpty()) message = "Error inesperado.";
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
