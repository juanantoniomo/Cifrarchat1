# Cifrarchat1

Primera versión Android funcional para cifrar y descifrar mensajes localmente.

## Qué hace ahora

- Cifra texto con AES-256-GCM.
- Deriva la clave desde una contraseña con PBKDF2-HMAC-SHA256 (210.000 iteraciones).
- Usa una sal y un IV aleatorios por mensaje.
- Permite copiar el mensaje cifrado para compartirlo por otra aplicación.
- Permite descifrar mensajes `CC1...` usando la misma contraseña.

## Qué falta para ser un chat completo

Esta versión todavía no incluye cuentas de usuario, servidor, entrega de mensajes, notificaciones ni intercambio automático de claves. Es un MVP de la parte de cifrado local.

## APK automático con GitHub Actions

El archivo `.github/workflows/android.yml` compila `app-debug.apk` en cada push a `main`.

En GitHub: **Actions > Android APK > último build > Artifacts > Cifrarchat1-debug-apk**.

## Requisitos Android

- Android 8.0 (API 26) o superior.
- Target/compile SDK 35.
